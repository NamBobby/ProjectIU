# forecastWeather Weather Forecast - Principle Database Management Course
-Parameters:
  * Pressure
  * Temperature
  * Humidity
  * Wind speed
