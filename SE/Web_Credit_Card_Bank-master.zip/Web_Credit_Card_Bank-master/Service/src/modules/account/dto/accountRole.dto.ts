
export enum role {
    User ='User',
    Admin = 'Admin'
}