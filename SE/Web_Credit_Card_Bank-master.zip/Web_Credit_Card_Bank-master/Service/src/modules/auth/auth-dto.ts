export type forgotPassDto = {
    PhoneNumber: number,
    ID: number,
    Email: string,
    NewPassword:string,
    Status: string
}